package com.example.monopolymoneytracker;

public class Accounter {
}
